// pages/_app.js
// Required by Next.js — wraps every page and loads global styles.
import '../styles/globals.css';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
