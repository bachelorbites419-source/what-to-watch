// pages/index.js
// The main home screen. Loads movies from TMDB for the user's country
// and displays them in a responsive grid of MovieCards.

import { useState, useEffect } from 'react';
import Head from 'next/head';
import CountrySelector from '../components/CountrySelector';
import MovieCard from '../components/MovieCard';
import { getUpcomingWithProviders } from '../lib/tmdb';

export default function Home() {
  const [country, setCountry] = useState('US');
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('all'); // 'all' | 'theatre' | 'streaming'

  // On first load — restore saved country preference
  useEffect(() => {
    const saved = localStorage.getItem('ww_country');
    if (saved) setCountry(saved);
  }, []);

  // Whenever country changes — fetch new movie list
  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const data = await getUpcomingWithProviders(country);
        if (!cancelled) setMovies(data);
      } catch {
        if (!cancelled) setError('Could not load movies. Please try again.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [country]);

  function handleCountryChange(code) {
    setCountry(code);
    localStorage.setItem('ww_country', code);
  }

  // Filter movies based on selected tab
  const visible = movies.filter((m) => {
    if (filter === 'all') return true;
    return m.venue === filter;
  });

  const theatreCount = movies.filter((m) => m.venue === 'theatre').length;
  const streamingCount = movies.filter((m) => m.venue === 'streaming').length;

  return (
    <>
      <Head>
        <title>Weekend Watch — What's Worth Watching This Week</title>
        <meta name="description" content="Community-voted weekly movie picks for theatres and streaming" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen bg-gray-50">

        {/* ── Header ── */}
        <header className="bg-white border-b border-gray-100 sticky top-0 z-20 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
                WW
              </div>
              <div>
                <h1 className="text-base font-bold text-gray-900 leading-tight">Weekend Watch</h1>
                <p className="text-xs text-gray-400 leading-tight hidden sm:block">
                  Vote now · Results every Friday
                </p>
              </div>
            </div>
            <CountrySelector selectedCountry={country} onCountryChange={handleCountryChange} />
          </div>
        </header>

        {/* ── Hero banner ── */}
        <div className="bg-gradient-to-r from-teal-700 to-teal-500 text-white">
          <div className="max-w-7xl mx-auto px-4 py-8">
            <h2 className="text-2xl sm:text-3xl font-bold mb-1">Coming this week</h2>
            <p className="text-teal-100 text-sm sm:text-base">
              Vote on what you're most excited to watch — results drop every Friday afternoon.
            </p>
          </div>
        </div>

        {/* ── Main ── */}
        <main className="max-w-7xl mx-auto px-4 py-6">

          {/* Filter tabs */}
          {!loading && movies.length > 0 && (
            <div className="flex gap-2 mb-6">
              {[
                { key: 'all', label: `All (${movies.length})` },
                { key: 'theatre', label: `🎬 Theatres (${theatreCount})` },
                { key: 'streaming', label: `📺 Streaming (${streamingCount})` },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setFilter(tab.key)}
                  className={`text-sm px-4 py-2 rounded-full font-medium transition-colors ${
                    filter === tab.key
                      ? 'bg-teal-600 text-white'
                      : 'bg-white text-gray-600 border border-gray-200 hover:border-teal-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          )}

          {/* Loading spinner */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-32 gap-3">
              <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-gray-400 text-sm">Loading movies for your country…</p>
            </div>
          )}

          {/* Error */}
          {error && !loading && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-8 text-center">
              <p className="text-red-600 mb-3">{error}</p>
              <button
                onClick={() => handleCountryChange(country)}
                className="text-sm text-red-500 underline"
              >
                Try again
              </button>
            </div>
          )}

          {/* Empty state */}
          {!loading && !error && movies.length === 0 && (
            <div className="text-center py-32 text-gray-400">
              <p className="text-5xl mb-4">🎬</p>
              <p className="text-lg font-medium text-gray-500">No upcoming movies found</p>
              <p className="text-sm mt-1">Try selecting a different country above.</p>
            </div>
          )}

          {/* Movie grid */}
          {!loading && visible.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {visible.map((movie) => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
            </div>
          )}

          {/* No results for filter */}
          {!loading && movies.length > 0 && visible.length === 0 && (
            <div className="text-center py-16 text-gray-400">
              <p>No {filter} releases found this week.</p>
              <button onClick={() => setFilter('all')} className="text-teal-600 text-sm mt-2 underline">
                Show all
              </button>
            </div>
          )}

        </main>

        {/* ── Footer ── */}
        <footer className="border-t border-gray-100 mt-12 py-8 text-center text-xs text-gray-300">
          <p>Weekend Watch · Movie data from <a href="https://www.themoviedb.org" className="underline" target="_blank" rel="noreferrer">TMDB</a> · Streaming info via JustWatch</p>
          <p className="mt-1">Votes reset every Monday · Results every Friday afternoon</p>
        </footer>

      </div>
    </>
  );
}
