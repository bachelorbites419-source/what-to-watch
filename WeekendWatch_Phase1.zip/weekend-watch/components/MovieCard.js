// components/MovieCard.js
// Displays a single movie: poster, title, release date, description,
// streaming platform logos, and a placeholder for the voting UI (Phase 2).

export default function MovieCard({ movie }) {
  const formattedDate = movie.releaseDate
    ? new Date(movie.releaseDate + 'T00:00:00').toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric',
      })
    : 'Date TBC';

  const badge =
    movie.venue === 'streaming'
      ? { label: 'Streaming', cls: 'bg-purple-600 text-white' }
      : { label: '🎬 In Theatres', cls: 'bg-teal-600 text-white' };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex flex-col hover:shadow-md transition-shadow duration-200">

      {/* Poster */}
      <div className="relative bg-gray-100" style={{ aspectRatio: '2/3' }}>
        {movie.poster ? (
          <img
            src={movie.poster}
            alt={movie.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-gray-300 text-4xl">🎬</span>
          </div>
        )}

        {/* Venue badge — top left */}
        <span className={`absolute top-2 left-2 text-xs font-semibold px-2 py-1 rounded-full ${badge.cls}`}>
          {badge.label}
        </span>

        {/* TMDB rating — top right */}
        {movie.tmdbRating && parseFloat(movie.tmdbRating) > 0 && (
          <span className="absolute top-2 right-2 text-xs font-bold px-2 py-1 rounded-full bg-black/60 text-yellow-400">
            ★ {movie.tmdbRating}
          </span>
        )}
      </div>

      {/* Info */}
      <div className="p-3 flex flex-col gap-1 flex-1">
        <h3 className="font-semibold text-gray-900 text-sm leading-tight line-clamp-2">
          {movie.title}
        </h3>
        <p className="text-xs text-gray-400">{formattedDate}</p>

        {movie.overview && (
          <p className="text-xs text-gray-500 mt-1 line-clamp-3 leading-relaxed">
            {movie.overview}
          </p>
        )}

        {/* Streaming logos */}
        {movie.providers?.streaming?.length > 0 && (
          <div className="mt-auto pt-2">
            <div className="flex flex-wrap gap-1">
              {movie.providers.streaming.slice(0, 4).map((p) => (
                <img
                  key={p.provider_id}
                  src={`https://image.tmdb.org/t/p/w45${p.logo_path}`}
                  alt={p.provider_name}
                  title={p.provider_name}
                  className="w-6 h-6 rounded object-cover"
                />
              ))}
              {movie.providers.streaming.length > 4 && (
                <span className="text-xs text-gray-400 self-center">
                  +{movie.providers.streaming.length - 4}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Voting placeholder — replaced in Phase 2 */}
        <div className="mt-3 pt-2 border-t border-gray-100">
          <p className="text-xs text-gray-300 text-center italic">Voting opens soon</p>
        </div>
      </div>

    </div>
  );
}
