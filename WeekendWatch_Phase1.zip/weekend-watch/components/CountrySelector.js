// components/CountrySelector.js
// Dropdown that lets the user pick their country.
// Selection is saved to localStorage so it persists on return visits.

import { SUPPORTED_COUNTRIES } from '../lib/tmdb';

export default function CountrySelector({ selectedCountry, onCountryChange }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-500 hidden sm:inline">Country:</span>
      <select
        value={selectedCountry}
        onChange={(e) => onCountryChange(e.target.value)}
        className="text-sm font-medium bg-white border border-gray-200 rounded-lg px-3 py-2 text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer shadow-sm"
      >
        {SUPPORTED_COUNTRIES.map((c) => (
          <option key={c.code} value={c.code}>
            {c.name}
          </option>
        ))}
      </select>
    </div>
  );
}
