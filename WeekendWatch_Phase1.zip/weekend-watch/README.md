# Weekend Watch 🎬

Community-voted weekly movie picks for theatres and streaming — results every Friday.

## Deploy in 2 minutes (no coding needed)

### Option A — Vercel (recommended, free)
1. Go to [vercel.com](https://vercel.com) and sign up with GitHub
2. Click **"Add New Project"** → **"Import Git Repository"**
3. Drag and drop this folder, OR use the Vercel CLI
4. In the **Environment Variables** section, add all variables from `.env.local`
5. Click **Deploy** — your app will be live at a `.vercel.app` URL

### Option B — Netlify (also free)
1. Go to [netlify.com](https://netlify.com) → **"Add new site"** → **"Deploy manually"**
2. Drag the project folder into the upload box
3. Add environment variables in Site Settings → Environment Variables
4. Done

## Environment Variables to add in Vercel/Netlify

```
NEXT_PUBLIC_TMDB_API_KEY
NEXT_PUBLIC_TMDB_READ_TOKEN
NEXT_PUBLIC_FIREBASE_API_KEY
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN
NEXT_PUBLIC_FIREBASE_PROJECT_ID
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID
NEXT_PUBLIC_FIREBASE_APP_ID
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID
SENDGRID_FROM_EMAIL
```

All values are in the `.env.local` file.

## What's been built (Phase 1)
- ✅ Firebase connection
- ✅ TMDB movie fetcher with streaming providers
- ✅ Home screen with movie grid
- ✅ Country selector (15 countries)
- ✅ Theatre vs Streaming filter tabs
- ✅ Movie cards with posters, badges, platform logos

## Coming next (Phase 2)
- Voting UI (star rating + excitement score)
- Firebase Auth (guest + email login)
- Votes saved to Firestore
